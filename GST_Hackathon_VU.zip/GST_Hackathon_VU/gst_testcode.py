# -*- coding: utf-8 -*-


import pickle

# Load the pickled model
with open('catboost_model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)


# Pickle the encoder (TargetEncoder)
with open('encoder.pkl', 'rb') as encoder_file:
    encoder = pickle.load(encoder_file)

# Pickle the scaler (StandardScaler)
with open('scaler.pkl', 'rb') as scaler_file:
    scaler = pickle.load(scaler_file)

# Pickle the imputer (SimpleImputer)
with open('imputer.pkl', 'rb') as imputer_file:
    imputer = pickle.load(imputer_file)
print("Model has been loaded!")

"""# Test Dataset"""

import pandas as pd
import numpy as np
from catboost import CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import IsolationForest
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, confusion_matrix
import category_encoders as ce  # For Target Encoding


# Load the test dataset and true labels
X_test = pd.read_csv('X_Test_Data_Input.csv').drop(columns=['ID'])
y_test = pd.read_csv('Y_Test_Data_Target.csv').drop(columns=['ID']).values.ravel()  # Flatten the target array


# Preprocessing steps for the test dataset
# Step 1: Handle Missing Values on test data
X_test_imputed = imputer.transform(X_test)

# Step 2: Feature Scaling on test data
X_test_scaled = scaler.transform(X_test_imputed)

# Step 3: Categorical Encoding on test data
categorical_cols = X_test.select_dtypes(include=['object', 'category']).columns
X_test_encoded = encoder.transform(X_test[categorical_cols])  # Use the same encoder fitted on training data

# Combine scaled numeric features and encoded categorical features for test
X_test_preprocessed = np.hstack([X_test_scaled, X_test_encoded])



# Step 5: Predict on the filtered test set
y_pred_test = model.predict(X_test_preprocessed)

# Step 6: Calculate accuracy
accuracy = accuracy_score(y_test, y_pred_test)  # Use only the non-outlier predictions
accuracy_percent = accuracy * 100

# Print accuracy
print("CatBoost Model Accuracy: {:.2f}%".format(accuracy_percent))

# Step 7: Save predictions to a DataFrame
predictions_df = pd.DataFrame({'Predicted': y_pred_test})

# Optional: Save predictions to a CSV file
predictions_df.to_csv('CatBoost_Test_Predictions.csv', index=False)

print("Predictions on the test dataset have been saved to 'CatBoost_Test_Predictions.csv'.")
