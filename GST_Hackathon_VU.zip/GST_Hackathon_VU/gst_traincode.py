

#!pip install catboost

#!pip install category_encoders

"""# Train Dataset"""

import pandas as pd
import numpy as np
from catboost import CatBoostClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import IsolationForest
import category_encoders as ce  # For Target Encoding
from sklearn.metrics import confusion_matrix, accuracy_score
import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, confusion_matrix
import matplotlib.pyplot as plt
from catboost import CatBoostClassifier

# Load the train datasets
X = pd.read_csv('X_Train_Data_Input.csv').drop(columns=['ID'])  # Drop ID column
y = pd.read_csv('Y_Train_Data_Target.csv').drop(columns=['ID']).values.ravel()  # Flatten the target array

# Load the test dataset and true labels
X_test = pd.read_csv('X_Test_Data_Input.csv').drop(columns=['ID'])
y_test = pd.read_csv('Y_Test_Data_Target.csv').drop(columns=['ID']).values.ravel()






# Step 1: Handle Missing Values
imputer = SimpleImputer(strategy='mean')
X_imputed = imputer.fit_transform(X)
X_test_imputed = imputer.transform(X_test)

# Step 2: Feature Scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_imputed)
X_test_scaled = scaler.transform(X_test_imputed)

# Step 3: Categorical Encoding
categorical_cols = X.select_dtypes(include=['object', 'category']).columns
encoder = ce.TargetEncoder(cols=categorical_cols)
X_encoded = encoder.fit_transform(X[categorical_cols], y)
X_test_encoded = encoder.transform(X_test[categorical_cols])

# Combine scaled numeric features and encoded categorical features for train and test sets
X_preprocessed = np.hstack([X_scaled, X_encoded])
X_test_preprocessed = np.hstack([X_test_scaled, X_test_encoded])

# --- Train the CatBoost Model ---
model = CatBoostClassifier(
    depth=8,
    learning_rate=0.05,
    iterations=1000,
    subsample=0.8,
    random_state=42,
    verbose=3
)

model.fit(X_preprocessed, y)

# --- Model Predictions ---
y_train_pred = model.predict(X_preprocessed)
y_train_pred_prob = model.predict_proba(X_preprocessed)[:, 1]  # For ROC AUC
y_test_pred = model.predict(X_test_preprocessed)
y_test_pred_prob = model.predict_proba(X_test_preprocessed)[:, 1]  # For ROC AUC

# --- Calculate Metrics ---

# Accuracy
train_accuracy = accuracy_score(y, y_train_pred)
test_accuracy = accuracy_score(y_test, y_test_pred)

# Precision
train_precision = precision_score(y, y_train_pred)
test_precision = precision_score(y_test, y_test_pred)

# Recall (Sensitivity or True Positive Rate)
train_recall = recall_score(y, y_train_pred)
test_recall = recall_score(y_test, y_test_pred)

# F1 Score
train_f1 = f1_score(y, y_train_pred)
test_f1 = f1_score(y_test, y_test_pred)

# AUC-ROC
train_roc_auc = roc_auc_score(y, y_train_pred_prob)
test_roc_auc = roc_auc_score(y_test, y_test_pred_prob)

# Confusion Matrix
train_conf_matrix = confusion_matrix(y, y_train_pred)
test_conf_matrix = confusion_matrix(y_test, y_test_pred)

# --- Display Metrics ---
print("---- Training Metrics ----")
print(f"Accuracy: {train_accuracy:.2f}")
print(f"Precision: {train_precision:.2f}")
print(f"Recall: {train_recall:.2f}")
print(f"F1 Score: {train_f1:.2f}")
print(f"ROC AUC: {train_roc_auc:.2f}")
print("Confusion Matrix:")
print(train_conf_matrix)

print("\n---- Test Metrics ----")
print(f"Accuracy: {test_accuracy:.2f}")
print(f"Precision: {test_precision:.2f}")
print(f"Recall: {test_recall:.2f}")
print(f"F1 Score: {test_f1:.2f}")
print(f"ROC AUC: {test_roc_auc:.2f}")
print("Confusion Matrix:")
print(test_conf_matrix)

# --- Plot the ROC Curve for the test set ---
fpr_test, tpr_test, _ = roc_curve(y_test, y_test_pred_prob)
plt.figure(figsize=(10, 6))
plt.plot(fpr_test, tpr_test, label=f'Test Set ROC AUC = {test_roc_auc:.2f}', color='green')

# Plot the diagonal (random guessing line)
plt.plot([0, 1], [0, 1], color='gray', linestyle='--')

# Labels and title
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve for Test Set')
plt.legend(loc='lower right')

# Show the plot
plt.show()

"""# Pickling the files"""

import pickle

# Assuming these objects have already been defined and used in your notebook
# 'model' is the CatBoostClassifier
# 'encoder' is the TargetEncoder used for categorical encoding
# 'scaler' is the StandardScaler for feature scaling
# 'imputer' is the SimpleImputer for handling missing values

# Pickle the CatBoost model
with open('catboost_model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)

# Pickle the encoder (TargetEncoder)
with open('encoder.pkl', 'wb') as encoder_file:
    pickle.dump(encoder, encoder_file)

# Pickle the scaler (StandardScaler)
with open('scaler.pkl', 'wb') as scaler_file:
    pickle.dump(scaler, scaler_file)

# Pickle the imputer (SimpleImputer)
with open('imputer.pkl', 'wb') as imputer_file:
    pickle.dump(imputer, imputer_file)

print("All objects have been pickled and saved!")

import pickle

# Assuming 'model' is your trained model (e.g., CatBoostClassifier)
with open('catboost_model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)

print("Model has been saved!")


